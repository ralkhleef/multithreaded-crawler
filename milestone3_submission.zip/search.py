import json
import os
import re
import math
from nltk.stem import PorterStemmer

ps = PorterStemmer()
INDEX_DIR = "partial_indexes"

def tokenize(text):
    return re.findall(r'\b\w+\b', text.lower())

def find_postings(term):
    postings = []
    doc_ids = set()
    for file in os.listdir(INDEX_DIR):
        if file.startswith("index_partial_") and file.endswith(".json"):
            try:
                with open(os.path.join(INDEX_DIR, file), 'r') as f:
                    part = json.load(f)
                    if term in part:
                        postings.extend(part[term])
                        for doc_id, _, _ in part[term]:
                            doc_ids.add(doc_id)
            except:
                continue
    return postings, doc_ids

def tfidf_ranking(query_terms, total_docs):
    scores = {}
    for term in query_terms:
        postings, doc_ids = find_postings(term)
        df = len(doc_ids)
        if df == 0:
            continue
        idf = math.log(total_docs / (1 + df))
        for doc_id, tf, importance in postings:
            score = tf * idf * importance
            scores[doc_id] = scores.get(doc_id, 0) + score
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)

def count_total_documents():
    seen = set()
    for file in os.listdir(INDEX_DIR):
        if file.startswith("index_partial_") and file.endswith(".json"):
            try:
                with open(os.path.join(INDEX_DIR, file), 'r') as f:
                    part = json.load(f)
                    for postings in part.values():
                        for doc_id, _, _ in postings:
                            seen.add(doc_id)
            except:
                continue
    return len(seen)

def main():
    total_docs = count_total_documents()

    with open('doc_id_map.json', 'r') as f:
        doc_id_map = json.load(f)

    while True:
        query = input("Search> ")
        if not query.strip():
            break
        terms = [ps.stem(w) for w in tokenize(query)]
        results = tfidf_ranking(terms, total_docs)

        if not results:
            print("No results found.")
            continue

        for doc_id, score in results[:10]:
            url = doc_id_map.get(str(doc_id), "Unknown Document")
            print(f"{url} — Score: {score:.2f}")

if __name__ == '__main__':
    main()
