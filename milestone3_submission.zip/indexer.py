import os
import json
import re
from collections import defaultdict
from nltk.stem import PorterStemmer
from bs4 import BeautifulSoup

ps = PorterStemmer()

def tokenize(text):
    return re.findall(r'\b\w+\b', text.lower())

def extract_important_words(html):
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text()
    important = []

    for tag in ['title', 'h1', 'h2', 'h3', 'strong', 'b']:
        for elem in soup.find_all(tag):
            important += tokenize(elem.get_text())

    return tokenize(text), important

def index_corpus(corpus_root, partial_limit=10):
    inverted_index = defaultdict(list)
    doc_id_map = {}
    doc_id = 0
    partial_count = 0

    print(f"Starting indexing in: {corpus_root}")

    for root, _, files in os.walk(corpus_root):
        for file in files:
            if not file.endswith('.json'):
                continue

            file_path = os.path.join(root, file)
            try:
                with open(file_path, 'r', encoding='utf8') as f:
                    data = json.load(f)
                    url = data.get('url')
                    html = data.get('content', '')
                    if not html:
                        continue
            except Exception as e:
                print(f"Skipped {file_path}: {e}")
                continue

            words, important_words = extract_important_words(html)
            term_freq = defaultdict(int)

            for word in words:
                stemmed = ps.stem(word)
                term_freq[stemmed] += 1

            for word, freq in term_freq.items():
                importance = 2 if word in important_words else 1
                inverted_index[word].append((doc_id, freq, importance))

            doc_id_map[doc_id] = url
            doc_id += 1

            if doc_id % partial_limit == 0:
                print(f"Saving partial index #{partial_count}")
                with open(f'index_partial_{partial_count}.json', 'w') as out:
                    json.dump(inverted_index, out)
                inverted_index = defaultdict(list)
                partial_count += 1

    if inverted_index:
        print(f"Saving final partial index #{partial_count}")
        with open(f'index_partial_{partial_count}.json', 'w') as out:
            json.dump(inverted_index, out)

    with open('doc_id_map.json', 'w') as out:
        json.dump(doc_id_map, out)

    print("Indexing complete.")
    print(f"Total documents indexed: {doc_id}")

if __name__ == '__main__':
    index_corpus('/home/ralkhlee/ics_data')

